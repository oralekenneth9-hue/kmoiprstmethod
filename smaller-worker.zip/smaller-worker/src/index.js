export default {
  async fetch(request, env) {
    // Serve everything in ./public (index.html and ffmpeg/*) as static files.
    return env.ASSETS.fetch(request);
  },
};
