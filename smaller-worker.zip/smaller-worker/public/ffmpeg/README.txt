Add these five files to this folder (ffmpeg/), exactly these names:

  ffmpeg.js          from @ffmpeg/ffmpeg@0.12.10/dist/umd/ffmpeg.js
  util.js            from @ffmpeg/util@0.12.1/dist/umd/index.js  (rename to util.js)
  814.ffmpeg.js      from @ffmpeg/ffmpeg@0.12.10/dist/umd/814.ffmpeg.js
  ffmpeg-core.js     from @ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.js
  ffmpeg-core.wasm   from @ffmpeg/core@0.12.6/dist/umd/ffmpeg-core.wasm

Get them from npm:  npm pack @ffmpeg/ffmpeg@0.12.10 @ffmpeg/util@0.12.1 @ffmpeg/core@0.12.6
or from unpkg/jsdelivr in a browser and save them under these names.
